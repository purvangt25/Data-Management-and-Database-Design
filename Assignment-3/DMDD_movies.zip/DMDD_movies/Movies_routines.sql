-- MySQL dump 10.13  Distrib 8.0.15, for macos10.14 (x86_64)
--
-- Host: localhost    Database: Movies
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `usecase_10`
--

DROP TABLE IF EXISTS `usecase_10`;
/*!50001 DROP VIEW IF EXISTS `usecase_10`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `usecase_10` AS SELECT 
 1 AS `movie_id`,
 1 AS `movie_names`,
 1 AS `Producers`,
 1 AS `Producer_user_id`,
 1 AS `User_id`,
 1 AS `User_Name`,
 1 AS `User_post`,
 1 AS `Date`,
 1 AS `Time`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `usecase_8`
--

DROP TABLE IF EXISTS `usecase_8`;
/*!50001 DROP VIEW IF EXISTS `usecase_8`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `usecase_8` AS SELECT 
 1 AS `movie_id`,
 1 AS `movie_names`,
 1 AS `year_release`,
 1 AS `metscores`,
 1 AS `imdb_ratings`,
 1 AS `runtime`,
 1 AS `User_ID`,
 1 AS `Caption`,
 1 AS `likes`,
 1 AS `Date`,
 1 AS `Time`,
 1 AS `director_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `usecase_3`
--

DROP TABLE IF EXISTS `usecase_3`;
/*!50001 DROP VIEW IF EXISTS `usecase_3`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `usecase_3` AS SELECT 
 1 AS `movie_id`,
 1 AS `movie_names`,
 1 AS `imdb_ratings`,
 1 AS `year_release`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `usecase_2`
--

DROP TABLE IF EXISTS `usecase_2`;
/*!50001 DROP VIEW IF EXISTS `usecase_2`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `usecase_2` AS SELECT 
 1 AS `movie_id`,
 1 AS `movie_names`,
 1 AS `imdb_ratings`,
 1 AS `year_release`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `usecase_5`
--

DROP TABLE IF EXISTS `usecase_5`;
/*!50001 DROP VIEW IF EXISTS `usecase_5`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `usecase_5` AS SELECT 
 1 AS `movie_names`,
 1 AS `genre`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `usecase_4`
--

DROP TABLE IF EXISTS `usecase_4`;
/*!50001 DROP VIEW IF EXISTS `usecase_4`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `usecase_4` AS SELECT 
 1 AS `movie_names`,
 1 AS `star_cast`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `usecase_7`
--

DROP TABLE IF EXISTS `usecase_7`;
/*!50001 DROP VIEW IF EXISTS `usecase_7`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `usecase_7` AS SELECT 
 1 AS `movie_id`,
 1 AS `movie_names`,
 1 AS `year_release`,
 1 AS `runtime`,
 1 AS `User_ID`,
 1 AS `Caption`,
 1 AS `likes`,
 1 AS `Date`,
 1 AS `Time`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `usecase_6`
--

DROP TABLE IF EXISTS `usecase_6`;
/*!50001 DROP VIEW IF EXISTS `usecase_6`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `usecase_6` AS SELECT 
 1 AS `movie_names`,
 1 AS `imdb_ratings`,
 1 AS `User_ID`,
 1 AS `Caption`,
 1 AS `likes`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `usecase_9`
--

DROP TABLE IF EXISTS `usecase_9`;
/*!50001 DROP VIEW IF EXISTS `usecase_9`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `usecase_9` AS SELECT 
 1 AS `avg(m_ratings.imdb_ratings)`,
 1 AS `avg(m_ratings.votes)`,
 1 AS `avg(m_ratings.metscores)`,
 1 AS `avg(m_ratings.runtime)`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `usecase_1`
--

DROP TABLE IF EXISTS `usecase_1`;
/*!50001 DROP VIEW IF EXISTS `usecase_1`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `usecase_1` AS SELECT 
 1 AS `movie_id`,
 1 AS `movie_names`,
 1 AS `imdb_ratings`,
 1 AS `year_release`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `usecase_10`
--

/*!50001 DROP VIEW IF EXISTS `usecase_10`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `usecase_10` AS select distinct `movies`.`movie_id` AS `movie_id`,`movies`.`movie_names` AS `movie_names`,`twitter_movies`.`Producers` AS `Producers`,`twitter_movies`.`User_id` AS `Producer_user_id`,`user_twitter`.`User_id` AS `User_id`,`user_twitter`.`User_Name` AS `User_Name`,`user_twitter`.`User_post` AS `User_post`,`user_twitter`.`Date` AS `Date`,`user_twitter`.`Time` AS `Time` from (((`movies` join `twitter_movies` on((`twitter_movies`.`movie_id` = `movies`.`movie_id`))) join `tweet_movies` on((`twitter_movies`.`movie_id` = `tweet_movies`.`movie_id`))) join `user_twitter` on((`user_twitter`.`User_id` = `tweet_movies`.`User_id`))) where (`twitter_movies`.`Producers` = '20th Century Fox') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `usecase_8`
--

/*!50001 DROP VIEW IF EXISTS `usecase_8`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `usecase_8` AS select distinct `movies`.`movie_id` AS `movie_id`,`movies`.`movie_names` AS `movie_names`,`m_ratings`.`year_release` AS `year_release`,`m_ratings`.`metscores` AS `metscores`,`m_ratings`.`imdb_ratings` AS `imdb_ratings`,`m_ratings`.`runtime` AS `runtime`,`user_insta`.`User_ID` AS `User_ID`,`user_insta`.`Caption` AS `Caption`,`user_insta`.`Likes` AS `likes`,`user_insta`.`Date` AS `Date`,`user_insta`.`Time` AS `Time`,`director`.`director_name` AS `director_name` from (((((`movies` join `m_ratings` on((`m_ratings`.`movie_id` = `movies`.`movie_id`))) join `insta_post` on((`insta_post`.`movie_id` = `movies`.`movie_id`))) join `user_insta` on((`insta_post`.`User_ID` = `user_insta`.`User_ID`))) join `m_director` on((`m_director`.`movie_id` = `movies`.`movie_id`))) join `director` on((`m_director`.`director_id` = `director`.`director_id`))) where ((`m_ratings`.`metscores` > 60) and (`m_ratings`.`imdb_ratings` > 7.5)) limit 5 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `usecase_3`
--

/*!50001 DROP VIEW IF EXISTS `usecase_3`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `usecase_3` AS select `movies`.`movie_id` AS `movie_id`,`movies`.`movie_names` AS `movie_names`,`m_ratings`.`imdb_ratings` AS `imdb_ratings`,`m_ratings`.`year_release` AS `year_release` from (`m_ratings` join `movies` on((`m_ratings`.`movie_id` = `movies`.`movie_id`))) where (`m_ratings`.`votes` > 20000) limit 5 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `usecase_2`
--

/*!50001 DROP VIEW IF EXISTS `usecase_2`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `usecase_2` AS select `movies`.`movie_id` AS `movie_id`,`movies`.`movie_names` AS `movie_names`,`m_ratings`.`imdb_ratings` AS `imdb_ratings`,`m_ratings`.`year_release` AS `year_release` from (`m_ratings` join `movies` on((`m_ratings`.`movie_id` = `movies`.`movie_id`))) where (`m_ratings`.`metscores` < 60) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `usecase_5`
--

/*!50001 DROP VIEW IF EXISTS `usecase_5`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `usecase_5` AS select `movies`.`movie_names` AS `movie_names`,`genre`.`genre` AS `genre` from ((`m_genre` join `movies` on((`m_genre`.`movie_id` = `movies`.`movie_id`))) join `genre` on((`m_genre`.`genre_id` = `genre`.`genre_id`))) where ((`movies`.`movie_names` = 'Bohemian Rhapsody') or (`movies`.`movie_names` = 'The Favourite')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `usecase_4`
--

/*!50001 DROP VIEW IF EXISTS `usecase_4`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `usecase_4` AS select `movies`.`movie_names` AS `movie_names`,`actor`.`star_cast` AS `star_cast` from ((`m_actor` join `movies` on((`m_actor`.`movie_id` = `movies`.`movie_id`))) join `actor` on((`m_actor`.`actor_id` = `actor`.`actor_id`))) where ((`movies`.`movie_names` = 'Green Book') or (`movies`.`movie_names` = 'Gully Boy')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `usecase_7`
--

/*!50001 DROP VIEW IF EXISTS `usecase_7`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `usecase_7` AS select `movies`.`movie_id` AS `movie_id`,`movies`.`movie_names` AS `movie_names`,`m_ratings`.`year_release` AS `year_release`,`m_ratings`.`runtime` AS `runtime`,`user_insta`.`User_ID` AS `User_ID`,`user_insta`.`Caption` AS `Caption`,`user_insta`.`Likes` AS `likes`,`user_insta`.`Date` AS `Date`,`user_insta`.`Time` AS `Time` from (((`movies` join `m_ratings` on((`m_ratings`.`movie_id` = `movies`.`movie_id`))) join `insta_post` on((`insta_post`.`movie_id` = `movies`.`movie_id`))) join `user_insta` on((`insta_post`.`User_ID` = `user_insta`.`User_ID`))) where (`movies`.`movie_names` = 'Green Book') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `usecase_6`
--

/*!50001 DROP VIEW IF EXISTS `usecase_6`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `usecase_6` AS select `movies`.`movie_names` AS `movie_names`,`m_ratings`.`imdb_ratings` AS `imdb_ratings`,`user_insta`.`User_ID` AS `User_ID`,`user_insta`.`Caption` AS `Caption`,`user_insta`.`Likes` AS `likes` from (((`movies` join `m_ratings` on((`m_ratings`.`movie_id` = `movies`.`movie_id`))) join `insta_post` on((`insta_post`.`movie_id` = `movies`.`movie_id`))) join `user_insta` on((`insta_post`.`User_ID` = `user_insta`.`User_ID`))) where (`user_insta`.`Likes` > 20) limit 5 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `usecase_9`
--

/*!50001 DROP VIEW IF EXISTS `usecase_9`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `usecase_9` AS select avg(`m_ratings`.`imdb_ratings`) AS `avg(m_ratings.imdb_ratings)`,avg(`m_ratings`.`votes`) AS `avg(m_ratings.votes)`,avg(`m_ratings`.`metscores`) AS `avg(m_ratings.metscores)`,avg(`m_ratings`.`runtime`) AS `avg(m_ratings.runtime)` from (`m_ratings` join `movies` on((`m_ratings`.`movie_id` = `movies`.`movie_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `usecase_1`
--

/*!50001 DROP VIEW IF EXISTS `usecase_1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `usecase_1` AS select `movies`.`movie_id` AS `movie_id`,`movies`.`movie_names` AS `movie_names`,`m_ratings`.`imdb_ratings` AS `imdb_ratings`,`m_ratings`.`year_release` AS `year_release` from (`m_ratings` join `movies` on((`m_ratings`.`movie_id` = `movies`.`movie_id`))) where (`m_ratings`.`imdb_ratings` > 7.5) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'Movies'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-25 22:58:20
