-- MySQL dump 10.13  Distrib 8.0.15, for macos10.14 (x86_64)
--
-- Host: localhost    Database: Movies
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `director`
--

DROP TABLE IF EXISTS `director`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `director` (
  `director_id` int(11) NOT NULL AUTO_INCREMENT,
  `director_name` text,
  PRIMARY KEY (`director_id`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `director`
--

LOCK TABLES `director` WRITE;
/*!40000 ALTER TABLE `director` DISABLE KEYS */;
INSERT INTO `director` VALUES (1,'Bryan Singer'),(2,'Peter Farrelly'),(3,'Robert Rodriguez'),(4,'Bradley Cooper'),(5,'Bob Persichetti'),(6,'Yorgos Lanthimos'),(7,'Dean DeBlois'),(8,'Stephen Merchant'),(9,'Sean Anders'),(10,'Spike Lee'),(11,'Anthony Russo'),(12,'Alfonso Cuarón'),(13,'Steven Caple Jr.'),(14,'Chiwetel Ejiofor'),(15,'Ryan Coogler'),(16,'David Leitch'),(17,'Damien Chazelle'),(18,'Ari Aster'),(19,'Ethan Coen'),(20,'Gaspar Noé'),(21,'Zoya Akhtar'),(22,'Barry Jenkins'),(23,'Brad Bird'),(24,'Steven Spielberg'),(25,'John Krasinski'),(26,'Marc Forster'),(27,'Nadine Labaki'),(28,'Pawel Pawlikowski'),(29,'Christopher McQuarrie'),(30,'Joe Berlinger'),(31,'Frant Gwo'),(32,'Joe Penna'),(33,'Hirokazu Koreeda'),(34,'Leigh Whannell'),(35,'Felix van Groeningen'),(36,'Bo Burnham'),(37,'Aneesh Chaganty'),(38,'S. Craig Zahler'),(39,'Gustav Möller'),(40,'Wes Anderson'),(41,'Chang-dong Lee'),(42,'Laure de Clermont-Tonnerre'),(43,'Jonah Hill'),(44,'Susan Johnson'),(45,'Tatsuya Nagamine'),(46,'Bo Hu'),(47,'Florian Henckel von Donnersmarck'),(48,'Greg Berlanti'),(49,'Jon S. Baird'),(50,'Mike Newell'),(51,'Matteo Garrone'),(52,'Carlos López Estrada'),(53,'Cristina Gallego'),(54,'Keith Behrman'),(55,'Scott Z. Burns'),(56,'Alice Rohrwacher'),(57,'Benedikt Erlingsson'),(58,'Tamara Jenkins'),(59,'Andrew Erwin'),(60,'Ty Roberts'),(61,'Britt Poulton'),(62,'Nuri Bilge Ceylan'),(63,'Erik Poppe'),(64,'Jennifer Fox'),(65,'Gavin Hood'),(66,'Severin Fiala'),(67,'Bart Freundlich'),(68,'Grant Sputore'),(69,'Zach Lipovsky'),(70,'Milorad Krstic');
/*!40000 ALTER TABLE `director` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-25 22:57:31
