-- MySQL dump 10.13  Distrib 8.0.15, for macos10.14 (x86_64)
--
-- Host: localhost    Database: Movies
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actor`
--

DROP TABLE IF EXISTS `actor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `actor` (
  `actor_id` int(11) NOT NULL AUTO_INCREMENT,
  `star_cast` longtext,
  PRIMARY KEY (`actor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=512 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actor`
--

LOCK TABLES `actor` WRITE;
/*!40000 ALTER TABLE `actor` DISABLE KEYS */;
INSERT INTO `actor` VALUES (1,'Bryan Singer'),(2,'Rami Malek'),(3,'Lucy Boynton'),(4,'Gwilym Lee'),(5,'Peter Farrelly'),(6,'Viggo Mortensen'),(7,'Mahershala Ali'),(8,'Linda Cardellini'),(9,'Robert Rodriguez'),(10,'Rosa Salazar'),(11,'Christoph Waltz'),(12,'Jennifer Connelly'),(13,'Bradley Cooper'),(14,'Lady Gaga'),(15,'Sam Elliott'),(16,'Bob Persichetti'),(17,'Peter Ramsey'),(18,'Rodney Rothman'),(19,'Shameik Moore'),(20,'Jake Johnson'),(21,'Yorgos Lanthimos'),(22,'Olivia Colman'),(23,'Emma Stone'),(24,'Rachel Weisz'),(25,'Dean DeBlois'),(26,'Jay Baruchel'),(27,'America Ferrera'),(28,'F. Murray Abraham'),(29,'Stephen Merchant'),(30,'Dwayne Johnson'),(31,'Lena Headey'),(32,'Vince Vaughn'),(33,'Sean Anders'),(34,'Mark Wahlberg'),(35,'Rose Byrne'),(36,'Isabela Moner'),(37,'Spike Lee'),(38,'John David Washington'),(39,'Adam Driver'),(40,'Laura Harrier'),(41,'Anthony Russo'),(42,'Joe Russo'),(43,'Robert Downey Jr.'),(44,'Chris Hemsworth'),(45,'Mark Ruffalo'),(46,'Alfonso Cuarón'),(47,'Yalitza Aparicio'),(48,'Marina de Tavira'),(49,'Diego Cortina Autrey'),(50,'Steven Caple Jr.'),(51,'Michael B. Jordan'),(52,'Sylvester Stallone'),(53,'Tessa Thompson'),(54,'Chiwetel Ejiofor'),(55,'Maxwell Simba'),(56,'Felix Lemburo'),(57,'Ryan Coogler'),(58,'Chadwick Boseman'),(59,'Lupita Nyong\'o'),(60,'David Leitch'),(61,'Ryan Reynolds'),(62,'Josh Brolin'),(63,'Morena Baccarin'),(64,'Damien Chazelle'),(65,'Ryan Gosling'),(66,'Claire Foy'),(67,'Jason Clarke'),(68,'Ari Aster'),(69,'Toni Collette'),(70,'Milly Shapiro'),(71,'Gabriel Byrne'),(72,'Ethan Coen'),(73,'Joel Coen'),(74,'Tim Blake Nelson'),(75,'Willie Watson'),(76,'Clancy Brown'),(77,'Gaspar Noé'),(78,'Sofia Boutella'),(79,'Romain Guillermic'),(80,'Souheila Yacoub'),(81,'Zoya Akhtar'),(82,'Ranveer Singh'),(83,'Alia Bhatt'),(84,'Siddhant Chaturvedi'),(85,'Barry Jenkins'),(86,'KiKi Layne'),(87,'Stephan James'),(88,'Regina King'),(89,'Brad Bird'),(90,'Craig T. Nelson'),(91,'Holly Hunter'),(92,'Sarah Vowell'),(93,'Steven Spielberg'),(94,'Tye Sheridan'),(95,'Olivia Cooke'),(96,'Ben Mendelsohn'),(97,'John Krasinski'),(98,'Emily Blunt'),(99,'Millicent Simmonds'),(100,'Marc Forster'),(101,'Ewan McGregor'),(102,'Hayley Atwell'),(103,'Bronte Carmichael'),(104,'Nadine Labaki'),(105,'Zain Al Rafeea'),(106,'Yordanos Shiferaw'),(107,'Boluwatife Treasure Bankole'),(108,'Pawel Pawlikowski'),(109,'Joanna Kulig'),(110,'Tomasz Kot'),(111,'Borys Szyc'),(112,'Christopher McQuarrie'),(113,'Tom Cruise'),(114,'Henry Cavill'),(115,'Ving Rhames'),(116,'Joe Berlinger'),(117,'Lily Collins'),(118,'Zac Efron'),(119,'Angela Sarafyan'),(120,'Frant Gwo'),(121,'Jing Wu'),(122,'Chuxiao Qu'),(123,'Guangjie Li'),(124,'Joe Penna'),(125,'Mads Mikkelsen'),(126,'Hirokazu Koreeda'),(127,'Lily Franky'),(128,'Sakura Andô'),(129,'Kirin Kiki'),(130,'Leigh Whannell'),(131,'Logan Marshall-Green'),(132,'Melanie Vallejo'),(133,'Steve Danielsen'),(134,'Felix van Groeningen'),(135,'Steve Carell'),(136,'Maura Tierney'),(137,'Jack Dylan Grazer'),(138,'Bo Burnham'),(139,'Elsie Fisher'),(140,'Josh Hamilton'),(141,'Emily Robinson'),(142,'Aneesh Chaganty'),(143,'John Cho'),(144,'Debra Messing'),(145,'Joseph Lee'),(146,'S. Craig Zahler'),(147,'Jennifer Carpenter'),(148,'Mel Gibson'),(149,'Michael Jai White'),(150,'Gustav Möller'),(151,'Jakob Cedergren'),(152,'Jessica Dinnage'),(153,'Omar Shargawi'),(154,'Wes Anderson'),(155,'Bryan Cranston'),(156,'Koyu Rankin'),(157,'Edward Norton'),(158,'Chang-dong Lee'),(159,'Ah-in Yoo'),(160,'Steven Yeun'),(161,'Jong-seo Jun'),(162,'Laure de Clermont-Tonnerre'),(163,'Matthias Schoenaerts'),(164,'Jason Mitchell'),(165,'Bruce Dern'),(166,'Jonah Hill'),(167,'Sunny Suljic'),(168,'Katherine Waterston'),(169,'Lucas Hedges'),(170,'Susan Johnson'),(171,'Lana Condor'),(172,'Noah Centineo'),(173,'Janel Parrish'),(174,'Tatsuya Nagamine'),(175,'Masako Nozawa'),(176,'Aya Hisakawa'),(177,'Ryô Horikawa'),(178,'Bo Hu'),(179,'Yu Zhang'),(180,'Yuchang Peng'),(181,'Uvin Wang'),(182,'Florian Henckel von Donnersmarck'),(183,'Tom Schilling'),(184,'Sebastian Koch'),(185,'Paula Beer'),(186,'Greg Berlanti'),(187,'Nick Robinson'),(188,'Jennifer Garner'),(189,'Josh Duhamel'),(190,'Jon S. Baird'),(191,'Steve Coogan'),(192,'John C. Reilly'),(193,'Shirley Henderson'),(194,'Mike Newell'),(195,'Jessica Brown Findlay'),(196,'Tom Courtenay'),(197,'Michiel Huisman'),(198,'Matteo Garrone'),(199,'Marcello Fonte'),(200,'Edoardo Pesce'),(201,'Nunzia Schiano'),(202,'Carlos López Estrada'),(203,'Daveed Diggs'),(204,'Rafael Casal'),(205,'Janina Gavankar'),(206,'Cristina Gallego'),(207,'Ciro Guerra'),(208,'Carmiña Martínez'),(209,'José Acosta'),(210,'Natalia Reyes'),(211,'Keith Behrman'),(212,'Maria Bello'),(213,'Taylor Hickson'),(214,'Kyle MacLachlan'),(215,'Scott Z. Burns'),(216,'Annette Bening'),(217,'Jon Hamm'),(218,'Alice Rohrwacher'),(219,'Alba Rohrwacher'),(220,'David Bennent'),(221,'Sergi López'),(222,'Benedikt Erlingsson'),(223,'Halldóra Geirharðsdóttir'),(224,'Jóhann Sigurðarson'),(225,'Juan Camillo Roman Estrada'),(226,'Tamara Jenkins'),(227,'Kathryn Hahn'),(228,'Paul Giamatti'),(229,'Gabrielle Reid'),(230,'Andrew Erwin'),(231,'Jon Erwin'),(232,'J. Michael Finley'),(233,'Madeline Carroll'),(234,'Dennis Quaid'),(235,'Ty Roberts'),(236,'Hassie Harrison'),(237,'Ali Cobrin'),(238,'Austin Nichols'),(239,'Britt Poulton'),(240,'Dan Madison Savage'),(241,'Kaitlyn Dever'),(242,'Walton Goggins'),(243,'Nuri Bilge Ceylan'),(244,'Dogu Demirkol'),(245,'Murat Cemcir'),(246,'Bennu Yildirimlar'),(247,'Erik Poppe'),(248,'Andrea Berntzen'),(249,'Aleksander Holmen'),(250,'Solveig Koløen Birkeland'),(251,'Jennifer Fox'),(252,'Elizabeth Debicki'),(253,'Laura Dern'),(254,'Ellen Burstyn'),(255,'Gavin Hood'),(256,'Keira Knightley'),(257,'Ralph Fiennes'),(258,'Matthew Goode'),(259,'Severin Fiala'),(260,'Veronika Franz'),(261,'Richard Armitage'),(262,'Riley Keough'),(263,'Alicia Silverstone'),(264,'Bart Freundlich'),(265,'Michelle Williams'),(266,'Julianne Moore'),(267,'Billy Crudup'),(268,'Grant Sputore'),(269,'Hilary Swank'),(270,'Clara Rugaard'),(271,'Zach Lipovsky'),(272,'Adam B. Stein'),(273,'Emile Hirsch'),(274,'Lexy Kolker'),(275,'Milorad Krstic'),(276,'Iván Kamarás'),(277,'Gabriella Hámori'),(278,'Zalán Makranczi');
/*!40000 ALTER TABLE `actor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-25 22:57:47
