-- MySQL dump 10.13  Distrib 8.0.15, for macos10.14 (x86_64)
--
-- Host: localhost    Database: Movies
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `m_genre`
--

DROP TABLE IF EXISTS `m_genre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `m_genre` (
  `movie_id` int(11) NOT NULL DEFAULT '0',
  `genre_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`movie_id`,`genre_id`),
  CONSTRAINT `m_genre_ibfk_1` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`movie_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_genre`
--

LOCK TABLES `m_genre` WRITE;
/*!40000 ALTER TABLE `m_genre` DISABLE KEYS */;
INSERT INTO `m_genre` VALUES (1,1),(1,2),(1,3),(2,1),(2,4),(2,5),(3,6),(3,7),(3,8),(4,8),(4,9),(4,10),(5,11),(5,12),(5,13),(6,1),(6,4),(6,5),(7,11),(7,12),(7,13),(8,1),(8,4),(8,5),(9,5),(9,14),(10,1),(10,5),(10,15),(11,6),(11,7),(11,16),(12,17),(13,9),(13,18),(14,17),(15,6),(15,7),(15,19),(16,6),(16,7),(16,20),(17,1),(17,2),(17,21),(18,9),(18,22),(18,23),(19,2),(19,14),(19,24),(20,3),(20,9),(20,22),(21,3),(21,9),(22,2),(22,8),(22,25),(23,11),(23,12),(23,13),(24,6),(24,7),(24,19),(25,9),(25,22),(25,23),(26,7),(26,11),(26,20),(27,17),(28,8),(28,9),(28,10),(29,6),(29,7),(29,26),(30,1),(30,15),(30,26),(31,27),(32,5),(32,28),(33,5),(33,25),(34,6),(34,26),(34,29),(35,1),(35,5),(36,5),(36,14),(37,9),(37,26),(37,30),(38,5),(38,6),(38,15),(39,2),(39,25),(39,26),(40,7),(40,11),(40,20),(41,9),(41,23),(42,17),(43,5),(43,14),(44,8),(44,9),(45,11),(45,12),(45,13),(46,17),(47,9),(47,26),(47,31),(48,2),(48,8),(48,14),(49,1),(49,4),(49,5),(50,8),(50,9),(50,31),(51,2),(51,25),(51,26),(52,5),(52,14),(52,15),(53,17),(54,17),(55,17),(56,17),(57,2),(57,6),(57,26),(58,17),(59,1),(59,2),(59,32),(60,8),(60,9),(60,31),(61,33),(62,17),(63,9),(63,26),(64,9),(64,26),(64,30),(65,1),(65,2),(65,26),(66,9),(66,22),(66,26),(67,17),(68,26),(68,34),(69,9),(69,26),(69,29),(70,11),(70,12),(70,35);
/*!40000 ALTER TABLE `m_genre` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-25 22:57:59
