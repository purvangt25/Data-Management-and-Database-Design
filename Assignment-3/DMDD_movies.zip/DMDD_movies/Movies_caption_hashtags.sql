-- MySQL dump 10.13  Distrib 8.0.15, for macos10.14 (x86_64)
--
-- Host: localhost    Database: Movies
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `caption_hashtags`
--

DROP TABLE IF EXISTS `caption_hashtags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `caption_hashtags` (
  `hashtag_id` int(11) NOT NULL AUTO_INCREMENT,
  `Caption_Hashtags` longtext,
  PRIMARY KEY (`hashtag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caption_hashtags`
--

LOCK TABLES `caption_hashtags` WRITE;
/*!40000 ALTER TABLE `caption_hashtags` DISABLE KEYS */;
INSERT INTO `caption_hashtags` VALUES (1,'freddiemercury'),(2,'bohemianrhapsody'),(3,'bohostyle'),(4,'benhardy'),(5,'freddiemercury_thelegend'),(6,'freddymercury'),(7,'boho'),(8,'benhardyobsessed'),(9,'family'),(10,'queen'),(11,'bohohippie'),(12,'marvel'),(13,'wod'),(14,'bohohippiechic'),(15,'statementearrings'),(16,'rogertaylor'),(17,'worldofdance'),(18,'movienight'),(19,'greenbook'),(20,'cinema'),(21,'shallow'),(22,'ladygaga'),(23,'astarisborn'),(24,'bradleycooper'),(25,'alwaysrememberusthisway'),(26,'mothermonster'),(27,'ladygagaedit'),(28,'illneverloveagain'),(29,'omaha'),(30,'thefavourite'),(31,'inkdrawing'),(32,'versace'),(33,'moviequotes'),(34,'artistsoninstagram'),(35,'sketchbook'),(36,'versaceonthefloor'),(37,'moviescenes'),(38,'drawing'),(39,'arabboys'),(40,'movierecommendation'),(41,'dailysketch'),(42,'yorgoslanthimos'),(43,'isabelamonerfan'),(44,'qotd'),(45,'isabelamoner'),(46,'isabela'),(47,'movie'),(48,'moner'),(49,'review'),(50,'film'),(51,'isabelaarmy'),(52,'likeplease'),(53,'instantfamily'),(54,'teammoner'),(55,'likeforlike'),(56,'kenzo'),(57,'roma'),(58,'concettopescecosta'),(59,'brindisi'),(60,'architectural'),(61,'blundstone'),(62,'italy'),(63,'posturas'),(64,'roadtrip'),(65,'sunsetdiaries'),(66,'fontanaditrevi'),(67,'rome'),(68,'caputmundi'),(69,'sunset'),(70,'streetwear'),(71,'photo'),(72,'stazione'),(73,'stazionetermini'),(74,'boy'),(75,'smile'),(76,'photos'),(77,'post__repost'),(78,'book'),(79,'darkness'),(80,'gasparnoe'),(81,'climax'),(82,'author'),(83,'read'),(84,'came'),(85,'climaxmovie'),(86,'bestoftheday'),(87,'photography'),(88,'back'),(89,'return'),(90,'instapic'),(91,'opus_dei'),(92,'books'),(93,'reading'),(94,'momvlogs'),(95,'murder2'),(96,'mushtaqhocane'),(97,'duniya'),(98,'filmy'),(99,'tseries'),(100,'student'),(101,'lukkachuppi'),(102,'akhil'),(103,'dilsambhaljaazara'),(104,'simple'),(105,'dhvanibhanushali'),(106,'momvlogger'),(107,'familyfest'),(108,'pink'),(109,'gullyboy'),(110,'momspresso'),(111,'reejafam'),(112,'ukraine'),(113,'towerblock'),(114,'secret'),(115,'filmpolonais'),(116,'bluedanube'),(117,'atombomb'),(118,'icbm'),(119,'housing'),(120,'secretbunker'),(121,'beaufilm'),(122,'nuclear'),(123,'coldwar'),(124,'architecture'),(125,'amour'),(126,'joannakulig'),(127,'nuclearweapons'),(128,'formerussr'),(129,'architravel'),(130,'tomaszkot'),(131,'atomicweapons'),(132,'topgear'),(133,'chernobyl'),(134,'london'),(135,'poplar'),(136,'brewdog'),(137,'canarywharf'),(138,'londoner'),(139,'bespokecakes'),(140,'city'),(141,'winterlights'),(142,'londondiaries'),(143,'cakesofinstagram'),(144,'foodie'),(145,'uk'),(146,'instacake'),(147,'eat'),(148,'visitlondon'),(149,'canarywharflondon'),(150,'dog'),(151,'americanpitbullterrier'),(152,'puppies'),(153,'bulldog'),(154,'puppy'),(155,'gameblood'),(156,'adba'),(157,'therealpitbull'),(158,'apbt'),(159,'maverick'),(160,'blindspotting'),(161,'solarbats'),(162,'indiatoday'),(163,'daveeddiggs'),(164,'movies'),(165,'york'),(166,'carloslopezestrada'),(167,'blindspot'),(168,'ekphrastic'),(169,'poem'),(170,'moviereviews'),(171,'rafaelcasal'),(172,'gigdates'),(173,'fellowship'),(174,'whitenoise'),(175,'dunestoneredemption'),(176,'2018'),(177,'politic'),(178,'play'),(179,'greendrink'),(180,'acousticband');
/*!40000 ALTER TABLE `caption_hashtags` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-25 22:58:15
