-- MySQL dump 10.13  Distrib 8.0.15, for macos10.14 (x86_64)
--
-- Host: localhost    Database: Movies
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `twitter_movies`
--

DROP TABLE IF EXISTS `twitter_movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `twitter_movies` (
  `movie_id` int(11) DEFAULT NULL,
  `Producers` text,
  `User_id` int(11) DEFAULT NULL,
  `Followers` int(11) DEFAULT NULL,
  `Post` text,
  `Post_ID` int(11) DEFAULT NULL,
  `Date` longtext,
  `Time` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `twitter_movies`
--

LOCK TABLES `twitter_movies` WRITE;
/*!40000 ALTER TABLE `twitter_movies` DISABLE KEYS */;
INSERT INTO `twitter_movies` VALUES (1,'20th Century Fox',203162990,3742372,'RT @THR: Don\'t stop him now. Best actor nominee and #BohemianRhapsody star Rami Malek – along with Lucy Boynton – has arrived at the #Oscar…',96,'Feb-25-2019','00:59:05'),(1,'20th Century Fox',203162990,3742372,'Mind control is simple yet powerful. Give it a try and show us your skills using #Bohemian Rhapsody',107,'Jan-20-2019','16:15:00'),(1,'20th Century Fox',203162990,3742372,'Go behind the scenes with @JimCameron, @JonLandau, @Rodriguez, Rosa Salazar, and the team at #Bohemian Rhapsody',108,'Jan-18-2019','01:00:00'),(1,'20th Century Fox',203162990,3742372,'RT @Bohemian Rhapsody: If you\'re a fan of #Bohemian Rhapsody, then you\'ll want to see the pages of @Bohemian Rhapsody come to life. Take a sneak peek inside of…',109,'Jan-14-2019','23:00:09'),(1,'20th Century Fox',203162990,3742372,'RT @goldenglobes: Congratulations to Bohemian Rhapsody (@BoRhapMovie) - Best Motion Picture - Drama. - #GoldenGlobes https://t.co/t46TX6xZhc',112,'Jan-07-2019','04:20:19'),(4,'Warner Bros. Pictures',20255162,4024388,'RT @starisbornmovie: The cast of #AStarIsBorn arrives on the #Oscars red carpet. https://t.co/GoAzHTySQd',9,'Feb-25-2019','01:15:51'),(4,'Warner Bros. Pictures',20255162,4024388,'RT @A Star Is Born: That Friday feeling. #A Star Is Born https://t.co/uKdW8LIEgE',11,'Feb-23-2019','18:30:14'),(4,'Warner Bros. Pictures',20255162,4024388,'RT @AStarIsBorn: Always. #WyldWednesdays #AStarIsBorn https://t.co/2N46ZPYlvd',12,'Feb-20-2019','23:03:50'),(4,'Warner Bros. Pictures',20255162,4024388,'RT @AStarIsBorn: Sing and dance along with your favorite characters to the Catchy Song on #FuseIt! ',18,'Feb-23-2019','23:11:04'),(12,'Paramount Pics',78734343,28337830,'RT @Roma: If you\'re a fan of #Roma, then you\'ll want to see the pages of @Roma come to life. Take a sneak peek inside ',113,'Jan-22-2019','06:21:36'),(12,'Paramount Pics',78734343,28337830,'RT @carrieunderwood: Just announced!!Roma',114,'Jan-10-2019','21:48:02'),(12,'Paramount Pics',78734343,28337830,'Check back here for trivia and use #Roma during the game for a chance to win a prize ',115,'Feb-23-2019','18:56:45'),(15,'Marvel Studios',751000000,2241495,'Congratulations to #BlackPanther on their Academy Award Win for Best Original Score! #Oscars https://t.co/SV7CHhC9wN',43,'Feb-25-2019','03:27:15'),(24,'Warner Bros. Pictures',20255162,4024388,'RT @readyplayerone: The Visual Effects team behind #ReadyPlayerOne has won for Outstanding Virtual Cinematography in a Photoreal Project! #…',28,'Feb-06-2019','06:23:51');
/*!40000 ALTER TABLE `twitter_movies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-25 22:57:43
