-- MySQL dump 10.13  Distrib 8.0.15, for macos10.14 (x86_64)
--
-- Host: localhost    Database: Movies
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `insta_hashtags`
--

DROP TABLE IF EXISTS `insta_hashtags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `insta_hashtags` (
  `movie_id` int(11) NOT NULL DEFAULT '0',
  `hashtag_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`movie_id`,`hashtag_id`),
  CONSTRAINT `insta_hashtags_ibfk_1` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`movie_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insta_hashtags`
--

LOCK TABLES `insta_hashtags` WRITE;
/*!40000 ALTER TABLE `insta_hashtags` DISABLE KEYS */;
INSERT INTO `insta_hashtags` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(2,18),(2,19),(2,20),(4,21),(4,22),(4,23),(4,24),(4,25),(4,26),(4,27),(4,28),(6,29),(6,30),(6,31),(6,32),(6,33),(6,34),(6,35),(6,36),(6,37),(6,38),(6,39),(6,40),(6,41),(6,42),(9,43),(9,44),(9,45),(9,46),(9,47),(9,48),(9,49),(9,50),(9,51),(9,52),(9,53),(9,54),(9,55),(12,12),(12,56),(12,57),(12,58),(12,59),(12,60),(12,61),(12,62),(12,63),(12,64),(12,65),(12,66),(12,67),(12,68),(12,69),(12,70),(12,71),(12,72),(12,73),(12,74),(12,75),(12,76),(20,20),(20,47),(20,77),(20,78),(20,79),(20,80),(20,81),(20,82),(20,83),(20,84),(20,85),(20,86),(20,87),(20,88),(20,89),(20,90),(20,91),(20,92),(20,93),(21,94),(21,95),(21,96),(21,97),(21,98),(21,99),(21,100),(21,101),(21,102),(21,103),(21,104),(21,105),(21,106),(21,107),(21,108),(21,109),(21,110),(21,111),(28,112),(28,113),(28,114),(28,115),(28,116),(28,117),(28,118),(28,119),(28,120),(28,121),(28,122),(28,123),(28,124),(28,125),(28,126),(28,127),(28,128),(28,129),(28,130),(28,131),(28,132),(28,133),(40,134),(40,135),(40,136),(40,137),(40,138),(40,139),(40,140),(40,141),(40,142),(40,143),(40,144),(40,145),(40,146),(40,147),(40,148),(40,149),(51,150),(51,151),(51,152),(51,153),(51,154),(51,155),(51,156),(51,157),(51,158),(51,159),(52,47),(52,160),(52,161),(52,162),(52,163),(52,164),(52,165),(52,166),(52,167),(52,168),(52,169),(52,170),(52,171),(52,172),(52,173),(52,174),(52,175),(52,176),(52,177),(52,178),(52,179),(52,180);
/*!40000 ALTER TABLE `insta_hashtags` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-25 22:57:23
