-- MySQL dump 10.13  Distrib 8.0.15, for macos10.14 (x86_64)
--
-- Host: localhost    Database: Movies
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `movies`
--

DROP TABLE IF EXISTS `movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `movies` (
  `movie_id` int(11) NOT NULL AUTO_INCREMENT,
  `movie_names` text,
  PRIMARY KEY (`movie_id`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movies`
--

LOCK TABLES `movies` WRITE;
/*!40000 ALTER TABLE `movies` DISABLE KEYS */;
INSERT INTO `movies` VALUES (1,'Bohemian Rhapsody'),(2,'Green Book'),(3,'Alita: Battle Angel'),(4,'A Star Is Born'),(5,'Spider-Man: Into the Spider-Verse'),(6,'The Favourite'),(7,'How to Train Your Dragon: The Hidden World'),(8,'Fighting with My Family'),(9,'Instant Family'),(10,'BlacKkKlansman'),(11,'Avengers: Infinity War'),(12,'Roma'),(13,'Creed II'),(14,'The Boy Who Harnessed the Wind'),(15,'Black Panther'),(16,'Deadpool 2'),(17,'First Man'),(18,'Hereditary'),(19,'The Ballad of Buster Scruggs'),(20,'Climax'),(21,'Gully Boy'),(22,'If Beale Street Could Talk'),(23,'Incredibles 2'),(24,'Ready Player One'),(25,'A Quiet Place'),(26,'Christopher Robin'),(27,'Capharnaüm'),(28,'Cold War'),(29,'Mission: Impossible - Fallout'),(30,'Extremely Wicked, Shockingly Evil, and Vile'),(31,'Liu Lang Di Qiu'),(32,'Arctic'),(33,'Shoplifters'),(34,'Upgrade'),(35,'Beautiful Boy'),(36,'Eighth Grade'),(37,'Searching'),(38,'Dragged Across Concrete'),(39,'The Guilty'),(40,'Isle of Dogs'),(41,'Burning'),(42,'The Mustang'),(43,'Mid90s'),(44,'To All the Boys I\'ve Loved Before'),(45,'Dragon Ball Super: Broly'),(46,'An Elephant Sitting Still'),(47,'Werk ohne Autor'),(48,'Love, Simon'),(49,'Stan & Ollie'),(50,'The Guernsey Literary and Potato Peel Pie Society'),(51,'Dogman'),(52,'Blindspotting'),(53,'Pájaros de verano'),(54,'Giant Little Ones'),(55,'The Report'),(56,'Happy as Lazzaro'),(57,'Kona fer í stríð'),(58,'Private Life'),(59,'I Can Only Imagine'),(60,'The Iron Orchard'),(61,'Them That Follow'),(62,'Ahlat Agaci'),(63,'Utøya: July 22'),(64,'The Tale'),(65,'Official Secrets'),(66,'The Lodge'),(67,'After the Wedding'),(68,'I Am Mother'),(69,'Freaks'),(70,'Ruben Brandt, Collector');
/*!40000 ALTER TABLE `movies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-25 22:57:55
