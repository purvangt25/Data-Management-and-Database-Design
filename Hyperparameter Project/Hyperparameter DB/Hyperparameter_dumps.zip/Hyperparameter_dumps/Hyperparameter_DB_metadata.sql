-- MySQL dump 10.13  Distrib 8.0.15, for macos10.14 (x86_64)
--
-- Host: localhost    Database: Hyperparameter_DB
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `metadata`
--

DROP TABLE IF EXISTS `metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `metadata` (
  `start_time` int(11) DEFAULT NULL,
  `target` text,
  `test_path` text,
  `max_models` text,
  `run_time` int(11) DEFAULT NULL,
  `Run_id` int(11) NOT NULL,
  `scale` text,
  `classification` text,
  `model_path` text,
  `balance` text,
  `balance_threshold` double DEFAULT NULL,
  `project` text,
  `end_time` int(11) DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  `nthreads` int(11) DEFAULT NULL,
  `min_mem_size` int(11) DEFAULT NULL,
  `analysis` int(11) DEFAULT NULL,
  `Main_Eval_metrix` text,
  `model_execution_time` double DEFAULT NULL,
  `mod_best` text,
  `mod_best_algo` text,
  PRIMARY KEY (`Run_id`),
  CONSTRAINT `Run_id` FOREIGN KEY (`Run_id`) REFERENCES `runs` (`Run_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metadata`
--

LOCK TABLES `metadata` WRITE;
/*!40000 ALTER TABLE `metadata` DISABLE KEYS */;
INSERT INTO `metadata` VALUES (1555711037,'TARGET_deathRate','null','null',333,1,'FALSE','FALSE','null','FALSE',0.2,'null',1555711037,0,1,5,2,'RMSE',282.183964,'StackedEnsemble_AllModels_AutoML_20190419_175717','stackedensemble'),(1555711964,'TARGET_deathRate','NA','NA',777,2,'FALSE','TRUE','NA','FALSE',0.2,'NA',1555711964,0,1,5,2,'RMSE',2199.539111,'GBM_grid_1_AutoML_20190419_181340_model_48','gbm'),(1555714740,'TARGET_deathRate','null','null',999,3,'FALSE','TRUE','null','FALSE',0.2,'null',1555714740,0,1,5,2,'RMSE',965.3840847,'GBM_grid_1_AutoML_20190419_181340_model_48','gbm'),(1555715983,'TARGET_deathRate','null','null',1333,4,'FALSE','TRUE','null','FALSE',0.2,'null',1555715983,0,1,5,2,'RMSE',1162.800776,'GBM_grid_1_AutoML_20190419_191951_model_48','gbm'),(1555717649,'TARGET_deathRate','null','null',1555,5,'FALSE','TRUE','null','FALSE',0.2,'null',1555717649,0,1,5,2,'RMSE',1460.965154,'GBM_grid_1_AutoML_20190419_191951_model_48','gbm');
/*!40000 ALTER TABLE `metadata` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-25 18:08:06
