-- MySQL dump 10.13  Distrib 8.0.15, for macos10.14 (x86_64)
--
-- Host: localhost    Database: Hyperparameter_DB
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `drf_hyperparameters`
--

DROP TABLE IF EXISTS `drf_hyperparameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `drf_hyperparameters` (
  `Algorithm_id` int(11) NOT NULL,
  `Run_id` int(11) DEFAULT NULL,
  `Leaderboard_rank` int(11) DEFAULT NULL,
  `nfolds` int(11) DEFAULT NULL,
  `seed` int(11) DEFAULT NULL,
  `mtries` int(11) DEFAULT NULL,
  `categorical_encoding` text,
  PRIMARY KEY (`Algorithm_id`),
  KEY `Run_id_idx` (`Run_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drf_hyperparameters`
--

LOCK TABLES `drf_hyperparameters` WRITE;
/*!40000 ALTER TABLE `drf_hyperparameters` DISABLE KEYS */;
INSERT INTO `drf_hyperparameters` VALUES (30001,1,23,5,27,-1,'AUTO'),(30002,1,24,5,27,-1,'AUTO'),(30003,2,55,5,27,-1,'AUTO'),(30004,2,56,5,27,-1,'AUTO'),(30005,2,57,5,27,-1,'AUTO'),(30006,2,58,5,27,-1,'AUTO'),(30007,3,90,5,27,-1,'AUTO'),(30008,3,91,5,27,-1,'AUTO'),(30009,3,92,5,27,-1,'AUTO'),(30010,3,93,5,27,-1,'AUTO'),(30011,3,94,5,27,-1,'AUTO'),(30012,3,95,5,27,-1,'AUTO'),(30013,4,135,5,27,-1,'AUTO'),(30014,4,136,5,27,-1,'AUTO'),(30015,4,137,5,27,-1,'AUTO'),(30016,4,138,5,27,-1,'AUTO'),(30017,4,139,5,27,-1,'AUTO'),(30018,4,140,5,27,-1,'AUTO'),(30019,4,141,5,27,-1,'AUTO'),(30020,4,142,5,27,-1,'AUTO'),(30021,5,184,5,27,-1,'AUTO'),(30022,5,185,5,27,-1,'AUTO'),(30023,5,186,5,27,-1,'AUTO'),(30024,5,187,5,27,-1,'AUTO'),(30025,5,188,5,27,-1,'AUTO'),(30026,5,189,5,27,-1,'AUTO'),(30027,5,190,5,27,-1,'AUTO'),(30028,5,191,5,27,-1,'AUTO'),(30029,5,192,5,27,-1,'AUTO'),(30030,5,193,5,27,-1,'AUTO');
/*!40000 ALTER TABLE `drf_hyperparameters` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-25 18:07:58
