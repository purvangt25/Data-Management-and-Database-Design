-- MySQL dump 10.13  Distrib 8.0.15, for macos10.14 (x86_64)
--
-- Host: localhost    Database: Hyperparameter_DB
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `glm_hyperparameters`
--

DROP TABLE IF EXISTS `glm_hyperparameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `glm_hyperparameters` (
  `Algorithm_id` int(11) NOT NULL,
  `Run_id` int(11) DEFAULT NULL,
  `Leaderboard_rank` int(11) DEFAULT NULL,
  `nfolds` int(11) DEFAULT NULL,
  `seed` int(11) DEFAULT NULL,
  `tweedie_variance_power` int(11) DEFAULT NULL,
  `tweedie_link_power` int(11) DEFAULT NULL,
  `missing_values_handling` text,
  `standardize` text,
  PRIMARY KEY (`Algorithm_id`),
  KEY `Run_id_idx` (`Run_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glm_hyperparameters`
--

LOCK TABLES `glm_hyperparameters` WRITE;
/*!40000 ALTER TABLE `glm_hyperparameters` DISABLE KEYS */;
INSERT INTO `glm_hyperparameters` VALUES (40001,1,22,5,27,0,1,'MeanImputation','TRUE'),(40002,2,53,5,27,0,1,'MeanImputation','TRUE'),(40003,2,54,5,27,0,1,'MeanImputation','TRUE'),(40004,3,87,5,27,0,1,'MeanImputation','TRUE'),(40005,3,88,5,27,0,1,'MeanImputation','TRUE'),(40006,3,89,5,27,0,1,'MeanImputation','TRUE'),(40007,4,131,5,27,0,1,'MeanImputation','TRUE'),(40008,4,132,5,27,0,1,'MeanImputation','TRUE'),(40009,4,133,5,27,0,1,'MeanImputation','TRUE'),(40010,4,134,5,27,0,1,'MeanImputation','TRUE'),(40011,5,179,5,27,0,1,'MeanImputation','TRUE'),(40012,5,180,5,27,0,1,'MeanImputation','TRUE'),(40013,5,181,5,27,0,1,'MeanImputation','TRUE'),(40014,5,182,5,27,0,1,'MeanImputation','TRUE'),(40015,5,183,5,27,0,1,'MeanImputation','TRUE');
/*!40000 ALTER TABLE `glm_hyperparameters` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-25 18:08:02
